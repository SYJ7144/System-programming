#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>


time_t start;

void f(int signum){
        time_t end=time(NULL);
	printf("Elapsed time: %d sec(s)\n",(int)(end-start));
}

int main(){
	start=time(NULL);

	void f(int);

	signal(SIGINT,f);
	printf("you can't stop me!\n");
	while(1){
		sleep(1);
		printf("haha\n");
	}
}
