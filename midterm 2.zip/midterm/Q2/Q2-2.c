#include <stdio.h>
#include <signal.h>
#include <unistd.h>


void safe_sleep(int time) {
    while (time > 0) {
        time = sleep(time);
    }

    return;
}
void my_int_handler(int s){
    printf("Ignored SIGINT");
    fflush(stdout);
}
void my_quit_handler(int s){
    printf("Ignored SIGQUIT");
    fflush(stdout);
}
int main() {
    struct sigaction sa;
    struct sigaction sa2;
    sigset_t mask,prev;

     sigemptyset(&sa.sa_mask);
     sa.sa_flags=0;
    sa.sa_handler=my_int_handler;
    sigemptyset(&sa2.sa_mask);
    sa2.sa_flags=0;
    sa2.sa_handler=my_quit_handler;
    if (sigaction(SIGINT,&sa,NULL)==-1) 
	
    {   
        perror("sigaction");
        exit(0);
    }

    if (sigaction(SIGQUIT,&sa2,NULL)==-1)
    {   
        perror("sigaction");
        exit(0);
    }
    sigemptyset(&mask);
    sigaddset(&mask,SIGINT);
    sigaddset(&mask,SIGQUIT);
    sigaddset(&mask,SIGTERM);
    sigprocmask(SIG_BLOCK,&mask,&prev);
    while(1){
    sigprocmask(SIG_BLOCK,&mask,&prev);
    printf("Signal is blocked for 10 seconds, signal_handler is not called.\n");
    safe_sleep(10);
    printf("Signal is blocked for 10 seconds, signal_handler is not called\n");
    sigprocmask(SIG_SETMASK,&prev,0);
    safe_sleep(5);
    
    }



    return 0;
}