#include <stdio.h>

int main(){
	int a;
	int b;
	a=0;
	b=10;
	int sum=a+b;
	a=5;

	int arr[11];
	arr[sum]=1;
	
	return 0;
}
