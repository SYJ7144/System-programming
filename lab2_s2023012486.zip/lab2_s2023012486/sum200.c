#include <stdio.h>

int main(){
	int result=0;
	
	for(int i=1; i<=200;i++){
		result+=i;
	}
	
	printf("The sum of 1 to 200 is %d\n",result);
	return 0;
}
