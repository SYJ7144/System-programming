#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int *partial_max_array;

void find_partial_max(int start, int end, int *array, int index) {
    int partial_max = array[start];
    for (int i = start + 1; i <= end; i++) {
        if (array[i] > partial_max) {
            partial_max = array[i];
        }
    }
    printf("[Child process:  %d] Max value(%d ~ %d) is %d\n", getpid(),start,end, partial_max);
    exit(partial_max);
}

int main() {
    FILE *file = fopen("array.txt", "r");
    int count;

    printf("Enter the number of child processes: ");
    scanf("%d", &count);

    if (file == NULL) {
        fprintf(stderr, "Error opening file.\n");
        return 1;
    }

    int array[100];
    int array_size = 0;

    printf("[Parent process: %d] Creating %d childeren...\n\n\n",getpid(),count);
    fscanf(file,"%d",&array[array_size++]);
    while (fscanf(file, "#%d", &array[array_size]) == 1) {
        array_size++;
    }
    fclose(file);
    
    int chunk_size = array_size / count;
    int remainder = array_size % count;
    partial_max_array = (int *)malloc(sizeof(int) * count);

    int start = 0;
    int status;
    for (int i = 0; i < count; i++) {
        
        
        int end = start + chunk_size-1;
         if (i < remainder) {
            end++;
        }
        pid_t pid = fork();
        

        if (pid == 0) { 
            find_partial_max(start, end, array, i);
        } else if (pid < 0) {
            fprintf(stderr, "Fork failed\n");
            return 1;
        }
        else{
            wait(&status);
            if(WIFEXITED(status))
            {
                partial_max_array[i]=WEXITSTATUS(status);
            }
        }

        start = end+1;
    }


    

    
    int min_partial_max = partial_max_array[0];
    for (int i = 1; i < count; i++) {
        if (partial_max_array[i] < min_partial_max) {
            min_partial_max = partial_max_array[i];
        }
    }
    

    printf("\nOverall min value is %d\n", min_partial_max);

    free(partial_max_array);

    return 0;
}
