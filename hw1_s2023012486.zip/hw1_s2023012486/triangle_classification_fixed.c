/**
 * ELEC462: HW#1 - gdb Exercise
 * School of Computer Science & Engineering
 * Kyungpook National University
 *
 * File name: triangle_classification_org.c
 * Writer: Prof. Y.-K. Suh 
 */

#include <stdio.h>
#include <math.h>

int main(int argc, char* argv[]){
	int i_a, i_b, i_c;
	int maxSide, side1, side2;

	printf("Enter the lengths of the three sides of the triangle:\n");

	printf("a: ");
	scanf("%d", &i_a);

	printf("b: ");
	scanf("%d", &i_b);

	printf("c: ");
	scanf("%d", &i_c);

	

    if (i_a > i_b && i_a > i_c) {
        maxSide = i_a;
        side1 = i_b;
        side2 = i_c;
    } else if (i_b > i_a && i_b > i_c) {
        maxSide = i_b;
        side1 = i_a;
        side2 = i_c;
    } else {
        maxSide = i_c;
        side1 = i_a;
        side2 = i_b;
    }


    int maxSideSq = pow(maxSide,2);
    int side1Sq = pow(side1,2);
    int side2Sq = pow(side2,2);


    if (side1Sq +side2Sq == maxSideSq) {
        printf("a^2 + b^2 = c^2\n");
        printf("The triangle is right.\n");
    } else if (side1Sq + side2Sq > maxSideSq) {
        printf("a^2 + b^2 > c^2\n");
        printf("The triangle is acute.\n");
    } else {
        printf("a^2 + b^2 < c^2\n");
        printf("The triangle is obtuse.\n");
    }



	return 0;
}
