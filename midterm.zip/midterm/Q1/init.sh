#!/bin/bash

# Ensure the script is running in a clean environment (optional: uncomment the next line if needed)
# rm -rf abc-topic test-topic

# Creating directories
mkdir -p abc-topic/abc-topic-p1
mkdir -p abc-topic/abc-topic-p2
mkdir -p abc-topic/abc-topic-p3
mkdir -p test-topic/test-topic-p1
mkdir -p test-topic/test-topic-p2

# Creating files
touch test-topic/test-topic-p1/0:hello
touch test-topic/test-topic-p2/0:system
touch test-topic/test-topic-p1/1:programming
touch abc-topic/abc-topic-p3/0:my
touch abc-topic/abc-topic-p2/0:name
touch abc-topic/abc-topic-p1/0:is
touch abc-topic/abc-topic-p3/1:abc
touch abc-topic/abc-topic-p2/1:chocolate
touch abc-topic/abc-topic-p1/1:and
touch abc-topic/abc-topic-p3/2:I
touch abc-topic/abc-topic-p2/2:love
touch abc-topic/abc-topic-p1/2:you

echo "Directory structure and files created successfully."
