#!/bin/bash

# Check if the correct number of arguments is passed
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <topic_name> <number_of_partitions>"
    exit 1
fi

# Extract arguments
topic_name=$1
number_of_partitions=$2

# Validate number of partitions is a positive integer
if ! [[ "$number_of_partitions" =~ ^[0-9]+$ ]] || [ "$number_of_partitions" -le 0 ]; then
    echo "Error: Number of partitions must be a positive integer."
    exit 1
fi

# Create the main topic directory
mkdir -p "$topic_name"

# Create each partition directory
for (( i=1; i<=number_of_partitions; i++ ))
do
    mkdir -p "${topic_name}/${topic_name}-p${i}"
done

echo "Topic and partitions created successfully."

