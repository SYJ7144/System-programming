/* Q1: Implementation of Kafka topic managment system

    Usage:
    -T <topic1> [<topic2> ...] --partition-info : Lists partitions and message counts.
    -T <topic1> [<topic2> ...] --all-msg : Lists all messages sorted by offset.
    -T <topic1> [<topic2> ...] --produce <message> : Produces a message to the least filled partition.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <limits.h>
#include <pwd.h>
#include <grp.h>

// Function declarations
void print_usage();
void list_partition_info(char** topics, int num_topics);
void list_all_messages(char** topics, int num_topics);
void produce_message(char** topics, int num_topics, char* message);
void dostat(char* filename);
void mode_to_letters(int mode, char str[]);
void show_file_info(char* filename, struct stat* info_p);

int partion_id=0;
int offset=0;


int main(int argc, char *argv[]) {
    
     if (argc < 2) {
        print_usage(); // (a)
        return 1;
    }

    if (strcmp(argv[1], "-T") == 0) {
        if (argc < 3) {
            print_usage();
            return 1;
        }
        
        int lastArg = 2;
        while (lastArg < argc && argv[lastArg][0] != '-') {
            lastArg++;
        }

        int num_topics = lastArg - 2;
        char** topics = &argv[2];

        if (argc > lastArg && strcmp(argv[lastArg], "--partition-info") == 0) {
            list_partition_info(topics, num_topics); // (b)
        } else if (argc > lastArg && strcmp(argv[lastArg], "--all-msg") == 0) {
            list_all_messages(topics, num_topics); //(c)
        } else if (argc > lastArg + 1 && strcmp(argv[lastArg], "--produce") == 0) {
            if (argc <= lastArg + 1) {
                printf("Error: Missing message content for --produce option.\n");
                return 1;
            }
            produce_message(topics, num_topics, argv[lastArg + 1]); // (d)
        } else {
            print_usage();
            return 1;
        }
    } else {
        print_usage();
        return 1;
    }



    return 0;
}


void print_usage() { 
    fprintf(stderr,"Usage:\n");
    fprintf(stderr,"-T <topic1> [<topic2> ...] --partition-info : Lists partitions and message counts.\n");
    fprintf(stderr,"-T <topic1> [<topic2> ...] --all-msg : Lists all messages sorted by offset.\n");
    fprintf(stderr,"-T <topic1> [<topic2> ...] --produce <message> : Produces a message to the least filled partition.\n");
}


void list_partition_info(char** topics, int num_topics) {
   
    DIR *dir_ptr;
    struct dirent *direntp;
    
    char path[256];
    
    int count=0;
    getcwd(path,sizeof(path));
    for(int i=0;i<num_topics;i++){
    printf("-- topic : %s --\n",*topics);
    chdir(*topics);
    getcwd(path,sizeof(path));
    if((dir_ptr=opendir(path))==NULL)
			fprintf(stderr,"cannot open %s\n",path);
	else{
		while((direntp=readdir(dir_ptr))!=NULL){
			if(strcmp(direntp->d_name,".")==0 ||
			   strcmp(direntp->d_name,"..")==0)
					continue;
			char path2[256];
            chdir(direntp->d_name);
            getcwd(path2,sizeof(path2));
            DIR *dirP_ptr;
            struct dirent *direntPp;
            if((dirP_ptr=opendir(path2))==NULL)
			    fprintf(stderr,"cannot open %s\n",path);
            count=0;
            while((direntPp=readdir(dirP_ptr))!=NULL){
			    if(strcmp(direntPp->d_name,".")==0 ||
			        strcmp(direntPp->d_name,"..")==0)
					    continue;
                count++;
            }
            printf("%s has %d msg.\n",direntp->d_name,count);
        
            chdir("..");
		}
    

   }
   *topics++;
   chdir("..");
}
}

void list_all_messages(char** topics, int num_topics) {
    DIR *dir_ptr;
    struct dirent *direntp;
    
    char path[256];
    
    int count=0;
    getcwd(path,sizeof(path));
    for(int i=0;i<num_topics;i++){
        printf("-- topic : %s --\n",*topics);
        chdir(*topics);
        getcwd(path,sizeof(path));
        if((dir_ptr=opendir(path))==NULL)
			fprintf(stderr,"cannot open %s\n",path);
	    else{
		    while((direntp=readdir(dir_ptr))!=NULL){
			    if(strcmp(direntp->d_name,".")==0 ||
			        strcmp(direntp->d_name,"..")==0)
					    continue;
			    char path2[256];
                chdir(direntp->d_name);
                getcwd(path2,sizeof(path2));
                DIR *dirP_ptr;
                struct dirent *direntPp;
                if((dirP_ptr=opendir(path2))==NULL)
			        fprintf(stderr,"cannot open %s\n",path);
                count=0;
                while((direntPp=readdir(dirP_ptr))!=NULL){
			        if(strcmp(direntPp->d_name,".")==0 ||
			            strcmp(direntPp->d_name,"..")==0)
					        continue;
                    dostat(direntPp->d_name);
            }
            chdir("..");
		}
    

   }
   *topics++;
   chdir("..");
}
}
void dostat(char* filename){
	struct stat info;
	if(stat(filename, &info)==-1)
		perror(filename);
	else
		show_file_info(filename, &info);
}

void show_file_info(char* filename, struct stat* info_p){
	
	char *ctime();
	void mode_to_letters();
	char modestr[] = "-----------";

	mode_to_letters(info_p->st_mode,modestr);
	printf("%s",modestr);
	
	printf("%.12s ", 4+ctime(&info_p->st_mtime));
	printf("%d %d ",partion_id,offset);
    printf("%s \n",filename);
}

void mode_to_letters(int mode, char str[]){
	if(S_ISDIR(mode)) str[0] = 'd';
	if(S_ISCHR(mode)) str[0]='c';
	if(S_ISBLK(mode)) str[0]='b';

	if(mode & S_IRUSR) str[1]='r';
	if(mode & S_IWUSR) str[2]='w';
	if(mode & S_IXUSR) str[3]='x';
       
      	if(mode & S_IRGRP) str[4]='r';
        if(mode & S_IWGRP) str[5]='w';
        if(mode & S_IXGRP) str[6]='x';

	if(mode & S_IROTH) str[7]='r';
        if(mode & S_IWOTH) str[8]='w';
        if(mode & S_IXOTH) str[9]='x';
}

void produce_message(char** topics, int num_topics, char* message) {
    /* ----- Question (d) ----- */
}