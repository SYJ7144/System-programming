#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

void my_int_handler(int s){
    printf("Ignored SIGINT");
    fflush(stdout);
}
void my_quit_handler(int s){
    printf("Ignored SIGQUIT");
    fflush(stdout);
}
int main() {
   
    struct sigaction sa;
    struct sigaction sa2;

    sigemptyset(&sa.sa_mask);
    sa.sa_flags=0;
    sa.sa_handler=my_int_handler;

    sigemptyset(&sa2.sa_mask);
    sa2.sa_flags=0;
    sa2.sa_handler=my_quit_handler;

    if (sigaction(SIGINT,&sa,NULL)==-1) 
	
    {   
        perror("sigaction");
        exit(0);
    }

    if (sigaction(SIGQUIT,&sa2,NULL)==-1)
    {   
        perror("sigaction");
        exit(0);
    }
    int count=0;
    while(1){
        sleep(1);
        printf("-- Loop... %d\n",++count);
    }

    return 0;   
}