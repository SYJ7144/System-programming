#include <stdio.h>
#include <signal.h>
#include <unistd.h>


void safe_sleep(int time) {
    while (time > 0) {
        time = sleep(time);
    }
    
    return;
}

int main() {



    
    return 0;
}