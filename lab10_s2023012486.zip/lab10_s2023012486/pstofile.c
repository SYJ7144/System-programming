#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

void main() {
    int pid, fd;
    printf("About to run ps -ef into a file\n");
    if ((pid = fork()) == -1) {
        perror("fork");
        exit(1);
    }
    if (pid == 0) {
        close(1);
        fd = creat("userlist", 0644);
        execlp("ps", "ps", "-ef", NULL); // Changed ps to ps -ef
        perror("execlp"); exit(1);
    }
    if (pid != 0) {
        wait(NULL);
        printf("Done running ps -ef, results in userlist\n");
    }
    return;
}
